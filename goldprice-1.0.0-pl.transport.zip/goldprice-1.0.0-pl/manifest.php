<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 Alexandr-GitHub

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'GoldPrice 1.0.0-pl

Dynamic gold pricing for MODX Revolution and miniShop2.
License: MIT.

After installation, configure goldprice.pf_url, goldprice.pf_sid and
goldprice.pf_bind_ip, then schedule the recalculation cron.

Uninstalling the package does not drop GoldPrice database tables or data.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e9e0cf3982b59336a6fe0731181e7543',
      'native_key' => 'goldprice',
      'filename' => 'modNamespace/99a6617280a803a128b9e6ba6fed722f.vehicle',
      'namespace' => 'goldprice',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'aa5b2618489a162e7b26d3cf45d5f786',
      'native_key' => 1,
      'filename' => 'modCategory/a504dcb1638e0db911d4929945c8292a.vehicle',
      'namespace' => 'goldprice',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80e4ea9c9c8b9bbb6719804484ea73d3',
      'native_key' => 'goldprice.pf_url',
      'filename' => 'modSystemSetting/7f1dc64a07b1fae935ef882c7a2d4926.vehicle',
      'namespace' => 'goldprice',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '751f91f0079ffd5d618c448bc272fbad',
      'native_key' => 'goldprice.pf_sid',
      'filename' => 'modSystemSetting/93477a0186d341495c26376a723332f0.vehicle',
      'namespace' => 'goldprice',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4da1ed4d9b08fad870a17e4d4a196503',
      'native_key' => 'goldprice.pf_tickers',
      'filename' => 'modSystemSetting/632ed9ed36460a14658a63101d540a24.vehicle',
      'namespace' => 'goldprice',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '169302df37fa5ff2324589556b7e74e5',
      'native_key' => 'goldprice.pf_bind_ip',
      'filename' => 'modSystemSetting/4a780b8fc179280fe9774d44295b1bc6.vehicle',
      'namespace' => 'goldprice',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a31dbb5b194df90826c0a2cd024b2373',
      'native_key' => 'goldprice.pf_timeout',
      'filename' => 'modSystemSetting/948333336bc721f721790b1582091877.vehicle',
      'namespace' => 'goldprice',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daffda03d5907e6a0489a9b5a8fad280',
      'native_key' => 'goldprice.quote_max_age',
      'filename' => 'modSystemSetting/a8c8404a44b23ede714caa5a319cb003.vehicle',
      'namespace' => 'goldprice',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba8ec92b0b4df3347e2e3bcb0a219805',
      'native_key' => 'goldprice.usd_max_age',
      'filename' => 'modSystemSetting/0bfde9e5e86ba10062d5723f60a8c570.vehicle',
      'namespace' => 'goldprice',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb92cd96d7065efaf9e8d2c3d284f372',
      'native_key' => 'goldprice.weight_tolerance',
      'filename' => 'modSystemSetting/ee38e81c529a56d30b7bf9f1b7e94cb2.vehicle',
      'namespace' => 'goldprice',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4590a44941e472438a5298632148643f',
      'native_key' => 'goldprice.vat_pct',
      'filename' => 'modSystemSetting/7c4c39fa99c51f701bb679552335a0a6.vehicle',
      'namespace' => 'goldprice',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9451087ad0a623082ac7fc468611f573',
      'native_key' => 'goldprice.recalc_lock_ttl',
      'filename' => 'modSystemSetting/98a19944eaf80f011772ce82d1bf68f3.vehicle',
      'namespace' => 'goldprice',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c109aeb215625b1594d95e553184749',
      'native_key' => 'goldprice.cart_ttl',
      'filename' => 'modSystemSetting/a047c0d055abb5040cb5169370d98691.vehicle',
      'namespace' => 'goldprice',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d28f3afebd787c729ce67c6d760d552',
      'native_key' => 'goldprice.storm_window',
      'filename' => 'modSystemSetting/ce3aa5c31da7e6f3ca6f4c4534c14dc7.vehicle',
      'namespace' => 'goldprice',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '537dcf695c077eb6b0de0f685b641fd9',
      'native_key' => 'goldprice.storm_duration',
      'filename' => 'modSystemSetting/64e47346129526c740301c556636db46.vehicle',
      'namespace' => 'goldprice',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3888789994aee39518981c6f03034524',
      'native_key' => 'goldprice.daily_buyout_limit',
      'filename' => 'modSystemSetting/08d26aecb5f9b4221cf87d29cae07ab2.vehicle',
      'namespace' => 'goldprice',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5886292fdf3b331f80353f1deadf87e7',
      'native_key' => 'goldprice.deal_buyout_limit',
      'filename' => 'modSystemSetting/595498ec495670e453453520859489dc.vehicle',
      'namespace' => 'goldprice',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ac395a1f5f8eb6b12bb438a12d4e49b',
      'native_key' => 'goldprice.mail_from',
      'filename' => 'modSystemSetting/ce6c6b4a6f7723dea24e454413e0b7fa.vehicle',
      'namespace' => 'goldprice',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '250fb81685a1ad0113cb41b5e59077a6',
      'native_key' => 'goldprice.mail_logo_url',
      'filename' => 'modSystemSetting/2ba34171fad0480c9bf13d7c0621c7a7.vehicle',
      'namespace' => 'goldprice',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '3b69d4ee8404280ba8ced08a4dd8c9ed',
      'native_key' => NULL,
      'filename' => 'modPlugin/65464fa73807965383ad6f468d9bc2db.vehicle',
      'namespace' => 'goldprice',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '7a7c01f1f3e08d7777d6244db25dabb6',
      'native_key' => NULL,
      'filename' => 'modSnippet/6a8b023de63557c9e5ae2abe2e654217.vehicle',
      'namespace' => 'goldprice',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '35bd1aefe792ec007083ba3e03084ad2',
      'native_key' => NULL,
      'filename' => 'modSnippet/03d816b7a878bec8c99def58b164e638.vehicle',
      'namespace' => 'goldprice',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '300f75cad756cd450339534deadee3ee',
      'native_key' => NULL,
      'filename' => 'modSnippet/24d3f843bd72610613a5bb30ed555000.vehicle',
      'namespace' => 'goldprice',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3c8c8240f690472622a1c10ae7c990a2',
      'native_key' => 'goldprice.menu',
      'filename' => 'modMenu/d989f82ecd8e42714f94e8f2bdf1774c.vehicle',
      'namespace' => 'goldprice',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fc0733999c23598c99f01fd99a7c21ab',
      'native_key' => 'fc0733999c23598c99f01fd99a7c21ab',
      'filename' => 'xPDOFileVehicle/9b34f16410c40ab5aebb597158c08e6f.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9a62b76e9d48951b797c610ffc968d0a',
      'native_key' => '9a62b76e9d48951b797c610ffc968d0a',
      'filename' => 'xPDOFileVehicle/5d14c8d02a26c39c7a71d9a4a9c05011.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '18cae1574b947b434a69b2ac6a6c86bf',
      'native_key' => '18cae1574b947b434a69b2ac6a6c86bf',
      'filename' => 'xPDOFileVehicle/e3e3f0083f978905725c577529058f54.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '57f191c1dd3e841089a84323f0ebc35b',
      'native_key' => '57f191c1dd3e841089a84323f0ebc35b',
      'filename' => 'xPDOFileVehicle/e7cd065dfb47cfaa3b9de4d2a1d04080.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '3a9109458ce271f3081c9726a3a24082',
      'native_key' => '3a9109458ce271f3081c9726a3a24082',
      'filename' => 'xPDOFileVehicle/c80e46d653d70aaab9593cb42e87cf3d.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1e1a78c1bba7826094c31ccf3a9e1372',
      'native_key' => '1e1a78c1bba7826094c31ccf3a9e1372',
      'filename' => 'xPDOFileVehicle/3e4fa4f030572f060bc384fdfcae575c.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c8c0c8a963666c1d47713b38dffcf42d',
      'native_key' => 'c8c0c8a963666c1d47713b38dffcf42d',
      'filename' => 'xPDOFileVehicle/d0c21c969a7b0433ab02157823acd938.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fbea6a5b916ce239b0e747a280c4e791',
      'native_key' => 'fbea6a5b916ce239b0e747a280c4e791',
      'filename' => 'xPDOFileVehicle/a72537bf1160d730e4ccf148ae49b9dc.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a2eb42182e787b2caa81cb4d5258f0d8',
      'native_key' => 'a2eb42182e787b2caa81cb4d5258f0d8',
      'filename' => 'xPDOFileVehicle/e9949a448cc15ea0448200a652e4de21.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ddcab8c43681f92f17df8d64d1323827',
      'native_key' => 'ddcab8c43681f92f17df8d64d1323827',
      'filename' => 'xPDOFileVehicle/26d8c93d580d55e34ca436be90fc4084.vehicle',
    ),
  ),
);
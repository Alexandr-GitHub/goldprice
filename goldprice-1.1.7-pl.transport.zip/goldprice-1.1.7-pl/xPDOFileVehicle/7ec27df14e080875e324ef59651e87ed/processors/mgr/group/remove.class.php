<?php

use GoldPrice\Mgr\GroupTrash;

class GoldPriceMgrGroupRemoveProcessor extends modProcessor
{
    public $languageTopics = ['goldprice:default'];
    public $permission = 'settings';
    public $objectType = 'goldprice.group';

    public function process()
    {
        $id = (int) $this->getProperty('id', 0);
        if ($id <= 0) {
            return $this->failure($this->modx->lexicon('invalid_data'));
        }

        /** @var GoldPriceGroup|null $object */
        $object = $this->modx->getObject('GoldPriceGroup', $id);
        if (!$object) {
            return $this->failure($this->modx->lexicon('object_not_found'));
        }
        if (GroupTrash::isDeleted($object->toArray())) {
            return $this->failure($this->modx->lexicon('goldprice.err_group_deleted'));
        }

        $allById = [];
        foreach ($this->modx->getCollection('GoldPriceGroup') as $group) {
            $allById[(int) $group->get('id')] = $group->toArray();
        }

        $plan = GroupTrash::planSoftDelete($object->toArray(), $allById);
        GroupTrash::applyProductMoves($this->modx, $plan['productMoves']);

        $now = date('Y-m-d H:i:s');
        foreach ($plan['softIds'] as $groupId) {
            /** @var GoldPriceGroup|null $row */
            $row = $this->modx->getObject('GoldPriceGroup', $groupId);
            if ($row) {
                $row->set('deleted_at', $now);
                $row->save();
            }
        }

        $title = (string) $object->get('title');
        $isRoot = (int) $object->get('parent_id') <= 0;
        $gp = $this->modx->goldprice;
        $summary = null;
        if ($gp) {
            $event = $isRoot ? 'group_root_remove' : 'group_subgroup_remove';
            $lex = $isRoot ? 'goldprice.log_group_root_remove' : 'goldprice.log_group_subgroup_remove';
            $gp->writeLog($event, $this->modx->lexicon($lex, ['title' => $title]), [
                'id' => $id,
                'soft_ids' => $plan['softIds'],
            ]);
            $summary = $gp->recalculatePrices();
        }

        if (is_array($summary)) {
            $message = isset($summary['message']) ? (string) $summary['message'] : '';

            return $this->success($message, $summary);
        }

        return $this->success();
    }
}

return 'GoldPriceMgrGroupRemoveProcessor';

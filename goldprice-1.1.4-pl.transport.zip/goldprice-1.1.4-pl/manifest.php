<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2026 Alexandr-GitHub

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'GoldPrice 1.1.4-pl

Dynamic gold pricing for MODX Revolution and miniShop2.
License: MIT.

After installation, configure goldprice.pf_url, goldprice.pf_sid and
goldprice.pf_bind_ip, then schedule the recalculation cron.

Uninstalling the package does not drop GoldPrice database tables or data.
',
    'changelog' => 'GoldPrice Changelog
===================

1.1.4-pl — 2026-09-14
---------------------
- Early migrate on namespace (parent_id before file copy).
- File vehicles use preexisting_mode=REMOVE (no preserved.zip hang on Beget).
- Fixed fatal in tables resolver (function called before definition).

1.1.3-pl — 2026-09-14
---------------------
- Category resolver before assets vehicle.

1.1.2-pl — 2026-09-14
---------------------
- Fixed resolver path after package folder rename.

1.1.1-pl — 2026-09-14
---------------------
- Changelog attribute for installer.

1.1.0-pl — 2026-09-14
---------------------
- Pricing subgroups (coin series).

1.0.1-pl / 1.0.0-pl — 2026-08-21
--------------------------------
- Initial releases.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a17a7c38930860fe3733da6a0c7ecd56',
      'native_key' => 'goldprice',
      'filename' => 'modNamespace/4071b8cc8762511dfe14fcc9b4fcaef1.vehicle',
      'namespace' => 'goldprice',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fa864b5a709ae19991f222d645156fe7',
      'native_key' => 'fa864b5a709ae19991f222d645156fe7',
      'filename' => 'xPDOFileVehicle/480592dadfcb5ea22fe88029915f7a46.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f2584b0eaa3c7582ad5161d0ee5d6c09',
      'native_key' => 'f2584b0eaa3c7582ad5161d0ee5d6c09',
      'filename' => 'xPDOFileVehicle/1a78aeacffd0eb4a837f12cb9820b4e5.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8142d7fd3be96cc0f9ad09e129c7f344',
      'native_key' => '8142d7fd3be96cc0f9ad09e129c7f344',
      'filename' => 'xPDOFileVehicle/d0b0023c494ab0bc5c725a2b47dcb772.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '896416424c48da8468ed2d0efff422c9',
      'native_key' => '896416424c48da8468ed2d0efff422c9',
      'filename' => 'xPDOFileVehicle/958c3d5d3e7093e54594221ed1930024.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b39cbed776c245b24d4e87ef5244f480',
      'native_key' => 'b39cbed776c245b24d4e87ef5244f480',
      'filename' => 'xPDOFileVehicle/836add1e2df6d3a47c0bad73624280eb.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '49ce2f34b2df83b295f647ef56cb1647',
      'native_key' => '49ce2f34b2df83b295f647ef56cb1647',
      'filename' => 'xPDOFileVehicle/7ec27df14e080875e324ef59651e87ed.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a3712df1084a5b112f6372cf88efdf69',
      'native_key' => 'a3712df1084a5b112f6372cf88efdf69',
      'filename' => 'xPDOFileVehicle/3f2f36b167bbf8eb7fd1b3f06bec3bf2.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9e64442a2ba4391c3ee697458cb2420f',
      'native_key' => '9e64442a2ba4391c3ee697458cb2420f',
      'filename' => 'xPDOFileVehicle/f2222df2f7cc51160559e3c03b639c04.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8bb8951aa0dde5d8e06210b4222de09e',
      'native_key' => '8bb8951aa0dde5d8e06210b4222de09e',
      'filename' => 'xPDOFileVehicle/75541c7f66daa0761d63025393b9a2c6.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '12b3d10ce178ca1d8030b3eab8dae8c1',
      'native_key' => 1,
      'filename' => 'modCategory/2dfceb2c9077da0728bf95a73b366ae1.vehicle',
      'namespace' => 'goldprice',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0684e6392cf8f6648209fe72646b3b5',
      'native_key' => 'goldprice.pf_url',
      'filename' => 'modSystemSetting/a2b0480bd3b0908b28b4e9ee36fdd4c7.vehicle',
      'namespace' => 'goldprice',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9b689af8b990c9efe37aac3b20667b7',
      'native_key' => 'goldprice.pf_sid',
      'filename' => 'modSystemSetting/b3f76eb5478d3afb79003213a33db96b.vehicle',
      'namespace' => 'goldprice',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc5b6005b38376bdeb83e29dfc702222',
      'native_key' => 'goldprice.pf_tickers',
      'filename' => 'modSystemSetting/a83e07f191d14e7ad4c73ed6a06ff8b0.vehicle',
      'namespace' => 'goldprice',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eec8fc431de9491c372ce88b13b1f3c6',
      'native_key' => 'goldprice.pf_bind_ip',
      'filename' => 'modSystemSetting/9b36428b45f1e42f1b8a54f9ba3f0a64.vehicle',
      'namespace' => 'goldprice',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '605e1cd28886b6502fd352dda599ecbf',
      'native_key' => 'goldprice.pf_timeout',
      'filename' => 'modSystemSetting/c8c8ac841920535836fee9ec4c0de0fa.vehicle',
      'namespace' => 'goldprice',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bef324c8e1758bc04c08b37012d62387',
      'native_key' => 'goldprice.quote_max_age',
      'filename' => 'modSystemSetting/ac03d66569447c71909ec9f0c28544c7.vehicle',
      'namespace' => 'goldprice',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1e59d993e98158a4330760d5a0d5c14',
      'native_key' => 'goldprice.usd_max_age',
      'filename' => 'modSystemSetting/b043f27e9230ba7960edf2982f592e11.vehicle',
      'namespace' => 'goldprice',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1f8ed96c52089d6ff35fbc261c17a08',
      'native_key' => 'goldprice.weight_tolerance',
      'filename' => 'modSystemSetting/0910591e9a6a39a1f84e005dfcd9e0bc.vehicle',
      'namespace' => 'goldprice',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0d8eb37f261ba2b4898d552507e3c6f',
      'native_key' => 'goldprice.vat_pct',
      'filename' => 'modSystemSetting/477226fb1fd0b98729951251db6bf857.vehicle',
      'namespace' => 'goldprice',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08aa1a04233fc0be566b47a1ffea1e1e',
      'native_key' => 'goldprice.recalc_lock_ttl',
      'filename' => 'modSystemSetting/598d1c70a84bdc4ceab5f7b7857c8033.vehicle',
      'namespace' => 'goldprice',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ca7d7fe263d1b732030e588879585e',
      'native_key' => 'goldprice.cart_ttl',
      'filename' => 'modSystemSetting/89826a2d073c92b54a791dd6c91171b9.vehicle',
      'namespace' => 'goldprice',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f4683a0c59e25472c08d9ee0d30fc18',
      'native_key' => 'goldprice.storm_window',
      'filename' => 'modSystemSetting/1ea3516c7bd5f473062828fb3b1c0184.vehicle',
      'namespace' => 'goldprice',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37b0d60243dbda1df36631224b8a70a5',
      'native_key' => 'goldprice.storm_duration',
      'filename' => 'modSystemSetting/8876edeb9812ad15c3fc65fb93dd4d86.vehicle',
      'namespace' => 'goldprice',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '393b9aa8efd58e70ea34126aa59414c9',
      'native_key' => 'goldprice.daily_buyout_limit',
      'filename' => 'modSystemSetting/7e44cad8f6afb0b85d9e8f81082ba362.vehicle',
      'namespace' => 'goldprice',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '993dd6489b56432a3ca3e27eee779ec5',
      'native_key' => 'goldprice.deal_buyout_limit',
      'filename' => 'modSystemSetting/e3a894e9d65278b77c7a147270a03300.vehicle',
      'namespace' => 'goldprice',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2741023721c35e512c6f83713c0f8c99',
      'native_key' => 'goldprice.mail_from',
      'filename' => 'modSystemSetting/75edb7448da209c6300c525a7211a25d.vehicle',
      'namespace' => 'goldprice',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74424b1d13b11e023c1c30b5b3ba481',
      'native_key' => 'goldprice.mail_logo_url',
      'filename' => 'modSystemSetting/b45a6737652b733c11911dddbaa0c368.vehicle',
      'namespace' => 'goldprice',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '9cc312c4672a3e1b00b4e90db3569393',
      'native_key' => NULL,
      'filename' => 'modPlugin/223c07efefe0a0610ac3e1ce5d9f0799.vehicle',
      'namespace' => 'goldprice',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '05e35d292313487f343222defbc623ef',
      'native_key' => NULL,
      'filename' => 'modSnippet/a85acba23a4d6fca789b4d7bf32eb053.vehicle',
      'namespace' => 'goldprice',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '43b9252e535c85f31cecbed938ead4ed',
      'native_key' => NULL,
      'filename' => 'modSnippet/2d64039668fa74fc098a087849b9418f.vehicle',
      'namespace' => 'goldprice',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '184af72e2a42d72db854ce1d7f0b7d02',
      'native_key' => NULL,
      'filename' => 'modSnippet/58af666bae600e8c1b6f9f18ad58af42.vehicle',
      'namespace' => 'goldprice',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ba12986b55f0a6f4dd22bc39e753c506',
      'native_key' => 'goldprice.menu',
      'filename' => 'modMenu/29e8aa211dc5c889339541dd8093592d.vehicle',
      'namespace' => 'goldprice',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8005fa23fa05a370449b7c192769518b',
      'native_key' => '8005fa23fa05a370449b7c192769518b',
      'filename' => 'xPDOFileVehicle/d5b3f54c3fcafd31f24f2a7c3bf8af81.vehicle',
    ),
  ),
);
